<?php
namespace app\index\controller;

class Index
{
    public function index()
    {
        return ['status'=>1,'msg'=>'请求成功'];
    }
}
