/** kit_admin-v1.1.0 MIT License By http://kit/zhengjinfan.cn e-mail:zheng_jinfan@126.com */
 ;layui.define(function(exports) {

    var kitconfig = {
        resourcePath: '/static/admin/', //框架资源路径-相对路径和绝对路径
    };

    exports('kitconfig', kitconfig);
});